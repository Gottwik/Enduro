{
	users: [
		{
			username: 'gottwik',
			tags: [],
			salt: 'dd536ca53d310c18d846c8864de4bab9',
			hash: '235726bc9363ff2d8f65228389dbae399470e3cce2f52aa9912b5b8634a5d87e',
			user_created_timestamp: 1471338975109
		}
	]
}
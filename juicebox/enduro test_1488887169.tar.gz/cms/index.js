{
	greeting: "you!",
	superlative: "nice",
}